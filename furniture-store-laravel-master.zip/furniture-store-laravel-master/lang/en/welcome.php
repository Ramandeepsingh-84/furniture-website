<?php
return ["welcome"=>"Welcome to class","gm"=>"Good morning to all"]
?>